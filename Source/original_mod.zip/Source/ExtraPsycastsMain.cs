﻿using Verse;
using Verse.AI;
using RimWorld;
using HarmonyLib;
using UnityEngine;

namespace ExtraPsycasts
{
	
	// Pyrokinesis
	public class CompProperties_ExtraPsycasts_Pyrokinesis : CompProperties_AbilityEffect
	{
		public CompProperties_ExtraPsycasts_Pyrokinesis()
		{ this.compClass = typeof(CompAbilityEffect_ExtraPsycasts_Pyrokinesis); }

		public float fireRadius;
	}

	public class CompAbilityEffect_ExtraPsycasts_Pyrokinesis : CompAbilityEffect
	{
		public new CompProperties_ExtraPsycasts_Pyrokinesis Props
		{
			get
			{ return (CompProperties_ExtraPsycasts_Pyrokinesis)this.props; }
		}

		public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
		{
			base.Apply(target, dest);
			GenExplosion.DoExplosion(target.Cell, this.parent.pawn.MapHeld, this.Props.fireRadius, DamageDefOf.Flame, null, 0, -1f, SoundDefOf.Interact_Ignite, null, null, null, ThingDefOf.Fire, 1f, 1, false, null, 0f, 1, 0f, false, null, null);
		}

		public override void DrawEffectPreview(LocalTargetInfo target)
		{
			GenDraw.DrawRadiusRing(target.Cell, this.Props.fireRadius);
		}
	}

	// Apply new thought
	public class CompProperties_ExtraPsycasts_ApplyThought : CompProperties_AbilityEffect
	{
		public CompProperties_ExtraPsycasts_ApplyThought()
		{ this.compClass = typeof(CompAbilityEffect_ExtraPsycasts_ApplyThought); }

		public ThoughtDef thought;
	}

	public class CompAbilityEffect_ExtraPsycasts_ApplyThought : CompAbilityEffect
	{
		public new CompProperties_ExtraPsycasts_ApplyThought Props
		{
			get
			{ return (CompProperties_ExtraPsycasts_ApplyThought)this.props; }
		}

		public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
		{
			base.Apply(target, dest);

			if (target.Pawn == null) { return; }
			target.Pawn.needs.mood.thoughts.memories.TryGainMemory(this.Props.thought, null);
		}
	}

	// Apply new methal state (can be null to remove mental states)
	public class CompProperties_ExtraPsycasts_ApplyMentalState : CompProperties_AbilityEffect
	{
		public CompProperties_ExtraPsycasts_ApplyMentalState()
		{ this.compClass = typeof(CompAbilityEffect_ExtraPsycasts_ApplyMentalState); }

		public MentalStateDef mentalState;
	}

	public class CompAbilityEffect_ExtraPsycasts_ApplyMentalState : CompAbilityEffect
	{
		public new CompProperties_ExtraPsycasts_ApplyMentalState Props
		{
			get
			{ return (CompProperties_ExtraPsycasts_ApplyMentalState)this.props; }
		}

		public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
		{
			base.Apply(target, dest);

			if (target.Pawn == null) { return; }
			if (target.Pawn.InMentalState == false) { return; }

			target.Pawn.MentalState.RecoverFromState();
			target.Pawn.jobs.ClearQueuedJobs(true);
			target.Pawn.jobs.EndCurrentJob(JobCondition.InterruptForced, true, true);

			if (this.Props.mentalState == null) { return; }
			target.Pawn.mindState.mentalStateHandler.TryStartMentalState(this.Props.mentalState, null, false, false, null, false);
		}
	}

	// Psylance
	public class CompProperties_ExtraPsycasts_PsyLance : CompProperties_AbilityEffect
	{
		public CompProperties_ExtraPsycasts_PsyLance()
		{ this.compClass = typeof(CompAbilityEffect_ExtraPsycasts_PsyLance); }

		public IntRange damageAmount = IntRange.zero;
		public DamageDef damageDef; 
	}

	public class CompAbilityEffect_ExtraPsycasts_PsyLance : CompAbilityEffect
	{
		public new CompProperties_ExtraPsycasts_PsyLance Props
		{
			get
			{ return (CompProperties_ExtraPsycasts_PsyLance)this.props; }
		}

		public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
		{
			base.Apply(target, dest);

			if (target.Pawn == null) { return; }

			BodyPartRecord brain = target.Pawn.health.hediffSet.GetBrain();
			if (brain == null) { return; }

			int randomInRange = this.Props.damageAmount.RandomInRange;
			DamageInfo damageInfo = new DamageInfo(this.Props.damageDef, (float)randomInRange, 0f, -1f, null, brain, null, DamageInfo.SourceCategory.ThingOrUnknown, null);
			damageInfo.SetIgnoreArmor(true);

			target.Pawn.TakeDamage(damageInfo);
		}
	}

	// Mind link
	public class HediffComp_Link_MindLink : HediffComp_Link
	{
		private MoteDualAttached mote;

		public override void CompPostTick(ref float severityAdjustment)
		{
			base.CompPostTick(ref severityAdjustment);
			if (this.drawConnection)
			{
				if (this.mote == null || this.mote.def.defName != "Mote_PsychicLinkLine_MindLink")
				{
					Log.Message("setting link color");
					if (this.mote != null) { this.mote.DeSpawn(); }
					ThingDef linkMote = DefDatabase<ThingDef>.GetNamed("Mote_PsychicLinkLine_MindLink");
					this.mote = MoteMaker.MakeInteractionOverlay(linkMote, this.parent.pawn, this.other);
				}
				this.mote.Maintain();
			}
		}
	}

	public class HediffCompProperties_MindLink : HediffCompProperties
	{
		public HediffCompProperties_MindLink()
		{ this.compClass = typeof(HediffComp_MindLink); }

		public float xpMultiplier = 1;
	}

	public class HediffComp_MindLink : HediffComp
	{
		public HediffCompProperties_MindLink Props
		{
			get
			{ return (HediffCompProperties_MindLink)this.props; }
		}
	}
}
