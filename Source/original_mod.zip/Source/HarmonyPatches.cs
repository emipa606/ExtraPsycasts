﻿using System;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;
using UnityEngine;

namespace ExtraPsycasts
{
	// Execute Harmony patching
	[StaticConstructorOnStartup]
	public class Main
	{
		static Main()
		{
			var harmony = new Harmony("io.github.chromiumboy.extrapsycasts");
			harmony.PatchAll(Assembly.GetExecutingAssembly());
		}
	}

	// Patch SkillRecord.Learn so experience can be shared when individuals are linked
	[HarmonyPatch(typeof(SkillRecord), "Learn")]
	static class ExtraPsycasts_SkillRecord_Learn_Postfix
	{
		// Access 'pawn' which is a private field
		static FieldInfo pawnField = AccessTools.Field(typeof(SkillRecord), "pawn");

		// Code postfix 
		static void Postfix(SkillRecord __instance, float xp, bool direct = false)
		{
			// Exit if there no gain in experience
			if (xp <= 0)
			{ return; }

			// Get the pawn which is gaining experience
			Pawn pawn = (pawnField.GetValue(__instance) as Pawn);

			// Loop over the pawn's hediffs
			foreach (Hediff hediff in pawn.health.hediffSet.hediffs)
			{
				// Continue if the hediff does not have the right components
				HediffComp_Link_MindLink hediffComp_Link_MindLink = hediff.TryGetComp<HediffComp_Link_MindLink>();
				HediffComp_MindLink hediffComp_MindLink = hediff.TryGetComp<HediffComp_MindLink>();
				if (hediffComp_Link_MindLink == null || hediffComp_MindLink == null) { continue; }

				// Otherwise pass this experience to the SkillRecord's new 'learn from another' method
				hediffComp_Link_MindLink.other.skills.GetSkill(__instance.def).LearnFromAnother(xp*hediffComp_MindLink.Props.xpMultiplier, direct);

				// Create motes to signify the transfer of experience
				Log.Message("setting pulse color");
				ThingDef mote = DefDatabase<ThingDef>.GetNamed("Mote_PsychicLinkPulse_MindLink");
				MoteMaker.MakeInteractionOverlay(mote, pawn, hediffComp_Link_MindLink.other);

				break;
			}
		}
	}
}
